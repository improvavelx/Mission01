package model;

public class Temperatura {
    private String cidade;
    private double temperatura;
    
    public String geCidade(){
        return cidade;
    }
    public double getTemperatura(){
        return temperatura;
    }
    public void setCidade(String cidade){
        this.cidade = cidade;
    }
    public double setTemperatura(){
        return temperatura;
    }
    public void setTemperatura(double temperatura){
        this.temperatura = temperatura;
    }
    public String classificar(){
        if (temperatura >=35) {      
            return "Temperatura Extemamente Alta";
        }
        else if (temperatura >= 30) {
            return "Temperatura Alta";
        }
        else if (temperatura >= 18) {
            return "Temperatura Agradavel";
        }
        else if (temperatura >= 3) {
            return "Temperatura Baixa";
        }
        else{ 
            return "Temperatura Extremamente baixa";
        }
    }
}