package view;

import java.util.Scanner;

public class TemperaturaView {
    private Scanner entrada = new Scanner(System.in);

    public String lerCidade() {
        System.out.print("Digite a cidade");
        return entrada.nextLine();
    }

    public double lerTemperatura(){
        double temp = 0;
        boolean valido = false;
        
      while (!valido) {
        try{
            System.out.print("Digite a Temperatura Atual: ");
            temp = entrada.nextDouble();
            valido = true;
        } catch(java.util.InputMismatchException e){
            System.out.println("Erro! Digite o número válido"); 
            entrada.nextLine();
        }
      }
      return temp;
    }
    public void mostrarResultado(String cidade, double temperatura, String situacao){
        System.out.println("\nCidade: "+cidade);
        System.out.println("Temperaruta: "+temperatura+" °C");
        System.out.println("Situação: " +situacao);       
    }
    public void fechar(){
        entrada.close();
    }
}
