package controller;
import model.Temperatura;
import view.TemperaturaView;

public class TemperaturaController {
    public static void main(String[] args) {
        Temperatura model = new Temperatura();
        TemperaturaView view = new TemperaturaView();

        model.setCidade(view.lerCidade());
        model.setTemperatura(view.lerTemperatura());

        String situacao = model.classificar();

        view.mostrarResultado(
            model.getCidade(),
            model.getTemperatura(),
            situacao);

            view.fechar();
    }
}