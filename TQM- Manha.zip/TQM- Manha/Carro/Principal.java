public class Principal {
    
    public static void main(String[] args) {

         //Criando objetos da classe        
         Carro carro1 = new Carro("Toyota", "Corolla", 2023, 135000);
         Carro carro2 = new Carro("Volkswagen", "Corolla", 1995, 500000);
         Carro carro3 = new Carro("Volkswagen", "Fusca", 2000, 16000);
         Carro carro4 = new Carro("Fiat", "Palio", 2001, 13000);
         Carro carro5 = new Carro("Ford", "Focus", 2015, 46000);


         //Exibindo os Dados
         carro1.mostrarDados();
         System.out.println();
         carro2.mostrarDados();
         System.out.println();
         carro3.mostrarDados();
         System.out.println();
         carro4.mostrarDados();
         System.out.println();
         carro5.mostrarDados();
         System.out.println();    
    }  
}
