//cria a Classe Carro, a forma do bolo
public class Carro{
    
    //Cria os atributos da Classe. Tudo aquilo que querro cadastrar
    String marca;
    String modelo;
    int ano;
    double valor;

    //Cria o metodo Construtor
    public Carro(String marca, String modelo, int ano, double valor){
  
        //O this recebe o valor
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
        this.valor = valor;
    }

    //Método para exibir informações
    public void mostrarDados(){
      
      //Exibe uma mensagem
      System.out.println("=== CARRO CADASTRADO ===");

      System.out.println("Marca: "+marca);

      System.out.println("Modelo: "+modelo);

      System.out.println("Ano do Carro: "+ano);

      System.out.println("Valor: R$ "+valor);
    }

    //Métodos get
    public String getMarca(){
        return marca;
    }
    public String getModelo(){
      return modelo;
    }
    public int getAno(){
        return ano;
    }
    public double getValor(){
        return valor;
    }

    //Métodos set
    public void setMarca(String marca){
        this.marca = marca;
    }
    public void setModelo(String modelo){
        this.modelo = modelo;
    }
    public void setAno(int ano){
        this.ano = ano;
    }
    public void setValor(double valor){
        this.valor = valor;
    }
}